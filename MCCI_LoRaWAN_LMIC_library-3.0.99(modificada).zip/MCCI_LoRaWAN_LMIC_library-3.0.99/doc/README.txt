DISCLAIMER:
Please note that the software is provided AS IS and we cannot
provide support for optimizations, adaptations, integration,
ports to other platforms or device drivers!
